﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanGiay.Models;

namespace WebBanGiay.Controllers
{
    public class GioHangController : Controller
    {
        QuanLyBanGiayEntities db = new QuanLyBanGiayEntities();
        // GET: GioHang
        #region Giỏ hàng
        public List<GioHang> LayGioHang()
        {
            //nếu giỏ hàng chưa tồn tại thì ta tiến hành khởi tạo list giỏ hàng session giohang
            List<GioHang> lstGioHang = Session["GioHang"] as List<GioHang>;
            if (lstGioHang == null)
            {
                lstGioHang = new List<GioHang>();
                Session["GioHang"] = lstGioHang;
            }
            return lstGioHang;
        }
        public ActionResult ThemGioHang(int iMaGiay,string DropSize)
        {
            Giay giay = db.Giays.SingleOrDefault(p => p.MaGiay == iMaGiay);
            int iSize = Convert.ToInt16(DropSize);
            if (giay == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            // lấy ra session giỏ hàng
            List<GioHang> lstGioHang = LayGioHang();
            // ktra sp này đã có trong giỏ hành chưa
            GioHang sp = lstGioHang.Find(p => p.iMaGiay == iMaGiay && p.iSize==iSize);
            if (sp == null)
            {
                sp = new GioHang(iMaGiay,iSize);
                lstGioHang.Add(sp);
                return RedirectToAction("GioHang");
            }
            else
            {
                sp.iSoLuong++;
                return RedirectToAction("GioHang");
            }
        }
        // cập nhập giỏ hàng
        public ActionResult CapNhapGioHang(int iMaGiay,int iSize, FormCollection f)
        {
            Giay s = db.Giays.SingleOrDefault(p => p.MaGiay == iMaGiay);
            if (s == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            List<GioHang> lstGioHang = LayGioHang();
            // ktra san phẩm có tổn tại trong giỏ hàng k
            GioHang sanpham = lstGioHang.SingleOrDefault(p => p.iMaGiay == iMaGiay&&p.iSize==iSize);
            if (sanpham != null)
            {
                sanpham.iSoLuong = int.Parse(f["txtSoLuong"].ToString());
            }
            return RedirectToAction("GioHang");
        }
        //xóa giỏ hàng
        public ActionResult XoaGioHang(int iMaGiay,int iSize )
        {
            Giay s = db.Giays.SingleOrDefault(p => p.MaGiay == iMaGiay);
            if (s == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            List<GioHang> lstGioHang = LayGioHang();
            // ktra san phẩm có tổn tại trong giỏ hàng k
            GioHang sanpham = lstGioHang.SingleOrDefault(p => p.iMaGiay == iMaGiay && p.iSize==iSize);
            if (sanpham != null)
            {
                lstGioHang.RemoveAll(p => p.iMaGiay == iMaGiay && p.iSize==iSize);
            }
            if (lstGioHang.Count == 0)
            {
                return RedirectToAction("Index", "Home");
            }
            return RedirectToAction("GioHang");

        }
        public ActionResult GioHang()
        {
            if (Session["GioHang"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<GioHang> lstGioHang = LayGioHang();

            return View(lstGioHang);
        }
        //Tính Tổng số lượng và tổng tiền
        private int TongSoLuong()
        {
            int iTongSoLuong = 0;
            List<GioHang> lstGioHang = Session["GioHang"] as List<GioHang>;
            if (lstGioHang != null)
            {
                iTongSoLuong = lstGioHang.Sum(p => p.iSoLuong);
            }
            return iTongSoLuong;
        }
        private double TongTien()
        {
            double dTongTien = 0;
            List<GioHang> lstGioHang = Session["GioHang"] as List<GioHang>;
            if (lstGioHang != null)
            {
                dTongTien = lstGioHang.Sum(p => p.dThanhTien);
            }
            return dTongTien;
        }
        public ActionResult GioHangPartial()
        {
            if (TongSoLuong() == 0)
            {

                ViewBag.TongSoLuong = 0;
                return PartialView();

            }
            ViewBag.TongSoLuong = TongSoLuong();
            ViewBag.TongTien = TongTien();
            return PartialView();
        }
        // xây dựng 1 view cho người dùng chỉnh sửa giỏ hàng
        public ActionResult SuaGioHang()
        {
            if (Session["GioHang"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<GioHang> lstGioHang = LayGioHang();

            return View(lstGioHang);
        }
        #endregion
        #region
        //xây dụng chức năng đặt hàng
        public ActionResult DatHang()
        {
            if (Session["TaiKhoan"] == null || Session["TaiKhoan"] == "")
            {
                return RedirectToAction("DangNhap", "NguoiDung");
            }
            //kiem tra gio hang
            if (Session["GioHang"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.TongTien = TongTien();
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            return View(kh);
        }
        [HttpPost]
        public ActionResult XacNhanDatHang(FormCollection f)
        {
            DonHangTong dh = new DonHangTong();
            KhachHang kh = (KhachHang)Session["TaiKhoan"];
            List<GioHang> lst = LayGioHang();
            string TenNguoiNhan = f["txtName"].ToString();
            string SDT = f["txtSDT"].ToString();
            string DiaChi = f["txtDiaChi"].ToString();
            dh.MaKH = kh.MaKH;
            dh.NgayDat = DateTime.Now;
            dh.TenNguoiNhan = TenNguoiNhan;
            dh.SoDienThoai = SDT;
            dh.DiaChi = DiaChi;
            dh.TongTien =Convert.ToInt32( TongTien());
            dh.TrangThai = 0;
            db.DonHangTongs.Add(dh);
            db.SaveChanges();
            List<HoSoShop> lstDH = new List<HoSoShop>();
            foreach(var item in lst)
            {
                Giay giay = db.Giays.SingleOrDefault(p => p.MaGiay == item.iMaGiay);
                HoSoShop shop =lstDH.SingleOrDefault(p => p.MaShop == giay.MaShop);
                if (shop == null)
                {
                    HoSoShop shop1 = db.HoSoShops.SingleOrDefault(p => p.MaShop == giay.MaShop);
                    lstDH.Add(shop1);
                }
            }
            foreach(var item in lstDH)
            {
                DonHang add = new DonHang();
                add.MaShop = item.MaShop;
                add.MaDH = dh.MaDH;
                add.TinhTrangGiaoHang = 0;
                add.TongTien =Convert.ToInt32( TongTienDH(item.MaShop));
                db.DonHangs.Add(add);
            }
            db.SaveChanges();
            // them chi tiet don hang
            foreach (var item in lst)
            {
                ChiTietDonHang ct = new ChiTietDonHang();
                ct.MaDH = dh.MaDH;
                ct.MaGiay = item.iMaGiay;
                ct.SoLuong = item.iSoLuong;
                ct.SizeGiay = item.iSize;
                db.ChiTietDonHangs.Add(ct);
                db.SaveChanges();
            }
            Session["GioHang"] = null;
            return RedirectToAction("Index","Home");
        }

        private double TongTienDH(int MaShop)
        {
            double Tong = 0;
            List<GioHang> lstGioHang = Session["GioHang"] as List<GioHang>;
            if (lstGioHang != null)
            {
                Tong = lstGioHang.Where(p => p.iMaShop == MaShop).Sum(p => p.dThanhTien);
            }
            return Tong;
        }

        [HttpPost]
        public JsonResult ThemGioHangAjax(int iMaGiay,int iSize)
        {
            Giay sach = db.Giays.SingleOrDefault(p => p.MaGiay == iMaGiay);
            bool check = true;
            if (sach == null)
            {
                check = false;
            }
            // lấy ra session giỏ hàng
            List<GioHang> lstGioHang = LayGioHang();
            // ktra sp này đã có trong giỏ hành chưa
            GioHang sp = lstGioHang.Find(p => p.iMaGiay == iMaGiay && p.iSize == iSize);
            if (sp == null)
            {
                sp = new GioHang(iMaGiay, iSize);
                lstGioHang.Add(sp);
                check = true;
            }
            else
            {
                sp.iSoLuong++;
                check = true;
            }
            return Json(new { status = check });
        }
        #endregion
    }
}