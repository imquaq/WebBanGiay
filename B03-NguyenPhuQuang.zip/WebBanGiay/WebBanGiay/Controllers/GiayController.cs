﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanGiay.Models;
using PagedList;
using PagedList.Mvc;
using System.Web.UI.WebControls;

namespace WebBanGiay.Controllers
{
    public class GiayController : Controller
    {
        QuanLyBanGiayEntities db = new QuanLyBanGiayEntities();
        // GET: Giay
        public ActionResult GiayTheoHang(int iMaHang,int? page)
        {
            HangGiay hg = db.HangGiays.SingleOrDefault(p => p.MaHangGiay == iMaHang);
            if (hg == null)
            {
                return RedirectToAction("Shop");
            }
            else
            {
                ViewBag.iMaHang = iMaHang;
                int pageSize = 9;
                int pageNumber = (page ?? 1);
                return View(db.Giays.Where(p => p.MaHang == iMaHang).ToList().ToPagedList(pageNumber,pageSize));
            }
        }
        public ActionResult Shop( int? page)
        {
            int pageSize = 9;
            int pageNumber = (page ?? 1);
            return View(db.Giays.Where(p=>p.TrangThai==2).ToList().ToPagedList(pageNumber, pageSize));
        }

        [HttpGet]
        public ActionResult XemChiTiet(int iMaGiay)
        {
            Giay sp = db.Giays.SingleOrDefault(p => p.MaGiay == iMaGiay);
            if(sp==null)
            {
                Response.StatusCode = 404;
                return null;
            }
            List< ChiTietAnhGiay> ct = db.ChiTietAnhGiays.Where(p => p.MaGiay == iMaGiay).ToList();
            ViewBag.CT = ct;
            return View(sp);
        }
        [HttpPost]
        public ActionResult XemChiTiet(int iMaGiay, string DropSize)
        {
            ViewBag.test = DropSize;
            Giay sp = db.Giays.SingleOrDefault(p => p.MaGiay == iMaGiay);
            if (sp == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(sp);
        }
        [HttpPost]
        public ActionResult TimKiem(int? page,FormCollection f)
        {
            string key = f["txtTimKiem"].ToString();
            ViewBag.Key = key;
            List<Giay> lst = db.Giays.Where(p => p.TenGiay.Contains(key)&& p.TrangThai==2).ToList();
            int pageSize = 9;
            int pageNumber = (page ?? 1);
            if (lst.Count == 0)
            {
                ViewBag.ThongBao = "Không tìm thấy sản phẩm nào";
                return View(db.Giays.OrderBy(p=>p.TenGiay).ToPagedList(pageNumber,pageSize));
            }
            ViewBag.ThongBao = "Đã tìm thấy " + lst.Count + " kết quả";
            return View(lst.OrderBy(p=>p.TenGiay).ToPagedList(pageNumber, pageSize));
        }
        [HttpGet]
        public ActionResult TimKiem(int? page,string key)
        {
            List<Giay> lst = db.Giays.Where(p => p.TenGiay.Contains(key)).ToList();
            int pageSize = 9;
            int pageNumber = (page ?? 1);
            if (lst.Count == 0)
            {
                ViewBag.ThongBao = "Không tìm thấy sản phẩm nào";
                return View(db.Giays.OrderBy(p => p.TenGiay).ToPagedList(pageNumber, pageSize));
            }
            ViewBag.ThongBao = "Đã tìm thấy " + lst.Count + " kết quả";
            return View(lst.OrderBy(p => p.TenGiay).ToPagedList(pageNumber, pageSize));
        }
        public ActionResult SizePartial(int iMaGiay)
        {
            List<ChiTietGiay> lst = db.ChiTietGiays.Where(p=>p.MaGiay==iMaGiay).ToList();
            SelectList catelist = new SelectList(lst, "Size", "Size");
            ViewBag.Cate = catelist;
            return PartialView(lst);
        }
    }
}