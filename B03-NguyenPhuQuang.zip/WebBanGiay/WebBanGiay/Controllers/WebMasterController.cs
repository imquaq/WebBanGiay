﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using WebBanGiay.Models;

namespace WebBanGiay.Controllers
{
    public class WebMasterController : Controller
    {
        QuanLyBanGiayEntities db = new QuanLyBanGiayEntities();
        // GET: WebMaster
        public ActionResult Index()
        {
            KhachHang kh = Session["Admin"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }
            List<DonHang> lsdh = db.DonHangs.Where(p => p.TinhTrangGiaoHang == 2).ToList();
            int? tam = 0;
            foreach (var i in lsdh)
            {
                tam += db.ChiTietDonHangs.Where(p => p.MaDH == i.MaDH && p.Giay.MaShop == i.MaShop).Sum(p => p.SoLuong);
            }
            ViewBag.TongDonHang = db.HoaDonGoiTins.Count();
            ViewBag.TongThanhVien = db.KhachHangs.Count();
            ViewBag.TongGoiTinDaBan = db.HoaDonGoiTins.Sum(p => p.GoiTin.Gia);
            ViewBag.TongSanPhamBanDuoc = tam;
            ViewBag.Name = kh.HoTen;
            return View(kh);
        }
        [HttpGet]
        public ActionResult DangNhap()
        {

            KhachHang kh = Session["Admin"] as KhachHang;
            if (kh != null)
            {
                return RedirectToAction("Index");
            }
            return View();
        }
        [HttpPost]
        public ActionResult DangNhap(FormCollection f)
        {
            string tk = f["txtTK"].ToString();
            string mk = MH.GetMD5(f["txtMK"].ToString());
            KhachHang kh = db.KhachHangs.SingleOrDefault(p => p.TaiKhoan == tk && p.MatKhau == mk);
            if (kh == null)
            {
                ViewBag.ThongBao = "Sai tài khoản hoặc mật khẩu";
                return View();
            }
            if (kh.Quyen!=3)
            {
                ViewBag.ThongBao = "Bạn không có quyền truy cập vào trang này";
                return View();
            }
            Session["Admin"] = kh;
            return RedirectToAction("Index");
        }
        public ActionResult QuanLyKhachHang()
        {
            KhachHang kh = Session["Admin"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }
            List<KhachHang> lsKhachHang = db.KhachHangs.Where(p=>p.TrangThai != null).OrderBy(p=>p.TrangThai).ToList();
            ViewBag.Name = kh.HoTen;
            return View(lsKhachHang);
        }

        public ActionResult QuanLyShop()
        {
            KhachHang kh = Session["Admin"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }

            List<HoSoShop> lsShop = db.HoSoShops.ToList();
            ViewBag.Name = kh.HoTen;
            return View(lsShop);
        }
        public ActionResult QuanLyGoiTin()
        {
            KhachHang kh = Session["Admin"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }
            List<GoiTin> lsGoiTin = db.GoiTins.ToList();
            ViewBag.Name = kh.HoTen;
            return View(lsGoiTin);
        }

        public ActionResult DuyetBaiDang()
        {
            KhachHang kh = Session["Admin"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }
            List<Giay> lsGiay = db.Giays.ToList();
            ViewBag.Name = kh.HoTen;
            return View(lsGiay);
        }

        public ActionResult DuyetMuaGoiTin()
        {
            KhachHang kh = Session["Admin"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }
            List<HoaDonGoiTin> lsMuaGoi = db.HoaDonGoiTins.ToList();
            ViewBag.Name = kh.HoTen;
            return View(lsMuaGoi);
        } 
        public ActionResult DangXuat()
        {
            Session["Admin"] = null;
            return RedirectToAction("DangNhap");
        }
        public ActionResult DuyetNapVi()
        {
            KhachHang kh = Session["Admin"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }
            List<HoaDonNapVi> hdv = db.HoaDonNapVis.ToList();
            ViewBag.Name = kh.HoTen;
            return View(hdv);
        }

        [HttpPost]

        public JsonResult LayGoi(int id)
        {
            GoiTin gt = db.GoiTins.Find(id);
            var maGoi = gt.MaGoi;
            var tenGoi = gt.TenGoi;
            var soLuong = gt.SoLuong;
            var gia = gt.Gia;
            return Json(new
            {
                maGoi,
                tenGoi,
                soLuong,
                gia,
                status = true
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult LuuGoi(string strgt)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            GoiTin gt = serializer.Deserialize<GoiTin>(strgt);

            bool status = false;
            string message = string.Empty;
            if (gt.MaGoi == 0)
            {
                try
                {
                    db.GoiTins.Add(gt);
                    db.SaveChanges();
                    status = true;
                }
                catch (Exception ex)
                {
                    status = false;
                    message = ex.Message;
                }
            }
            else
            {
                var entity = db.GoiTins.Find(gt.MaGoi);
                entity.TenGoi = gt.TenGoi;
                entity.SoLuong = gt.SoLuong;
                entity.Gia = gt.Gia;
                try
                {
                    db.SaveChanges();
                    status = true;
                }
                catch (Exception ex)
                {
                    status = false;
                    message = ex.Message;
                }
            }
            return Json(new
            {
                status = status,
                message = message
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult LuuKhachHang(string strkh)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            KhachHang kh = serializer.Deserialize<KhachHang>(strkh);

            bool status = false;
            string message = string.Empty;
            try
            {
                db.KhachHangs.Add(kh);
                db.SaveChanges();
                message = "Thêm thành công.";
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
                message = ex.Message;
            }
            return Json(new
            {
                status = status,
                message = message
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateTrangThaiShop(int id, string  lydo)
        {
            HoSoShop shop = db.HoSoShops.Find(id);
            bool status = false;
            string mess = string.Empty;
            if (shop.TrangThai == 0)
            {
                shop.TrangThai = 1;
                shop.GhiChu = "";
                db.SaveChanges();
                mess = "Kích hoạt thành công";
                status = true;
            }
            else
            {
                shop.TrangThai = 0;
                shop.GhiChu = lydo;
                db.SaveChanges();
                mess = "Đã vô hiệu hóa";
                status = false;
            }
            return Json(new
            {
                mess,
                status
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateTrangThaiGiay(int id, int value)
        {
            Giay giay = db.Giays.Find(id);
            bool status = false;
            string message = string.Empty;
            if (value == 0)
            {
                giay.TrangThai = value;
                giay.HoSoShop.SoTinTon++;
                db.SaveChanges();
                message = "Đã từ chối sản phẩm.";
                status = true;
            }
            else
            {
                giay.TrangThai = value;
                db.SaveChanges();
                message = "Chấp nhận sản phẩm. Sản phẩm đã được hiển thị.";
                status = true;
            }
            return Json(new
            {
                status,
                message
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateTrangThaiKH(int id,string lydo)
        {
            KhachHang kh = db.KhachHangs.Find(id);
            bool status = false;
            string mess = string.Empty;
            if (kh.TrangThai == 1)
            {
                kh.TrangThai = 2;
                kh.GhiChu = lydo;
                db.SaveChanges();
                mess = "Đã vô hiệu hóa";
                status = true;
            }
            else 
            if (kh.TrangThai == 2)
            {
                kh.TrangThai = 1;
                kh.GhiChu = "";
                db.SaveChanges();
                mess = "Kích hoạt lại thành công";
                status = true;
            }
            return Json(new
            {
                mess,
                status
            },JsonRequestBehavior.AllowGet);
        }

        public JsonResult AnHienGiay(int id)
        {
            Giay giay = db.Giays.Find(id);
            bool status = false;
            string message = string.Empty;
            if (giay.TrangThai == 3)
            {
                giay.TrangThai = 2;
                db.SaveChanges();
                message = "Đã hiển thị lại sản phẩm";
                status = true;
            }
            else
            {
                if (giay.TrangThai == 2)
                {
                    giay.TrangThai = 3;
                    db.SaveChanges();
                    message = "Đã ẩn sản phẩm";
                    status = true;
                }
            }
            return Json(new
            {
                message,
                status
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult LayThongTinGiay(int id)
        {
            Giay giay = db.Giays.Find(id);
            var tenShop = giay.HoSoShop.TenShop;
            var tenSanPham = giay.TenGiay;
            var tenHang = giay.HangGiay.TenHang;
            var giaBan = @String.Format("{0:0,0 VNĐ}", giay.GiaBan);
            var moTa = giay.MoTa;
            return Json(new
            {
                tenShop,
                tenHang,
                tenSanPham,
                giaBan,
                moTa,
                status = true
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateGoiTin(int id)
        {
            GoiTin gt = db.GoiTins.Find(id);
            string mess = string.Empty;
            bool status = false;
            if (gt.TrangThai == 0)
            {
                gt.TrangThai = 1;
                db.SaveChanges();
                status = true;
                mess = "Kích hoạt lại gói tin thành công.";
            }
            else
            {
                gt.TrangThai = 0;
                db.SaveChanges();
                status = true;
                mess = "Đã ẩn gói tin thành công";
            }
            return Json(new
            {
                mess,
                status
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult LayThongTinVi(int id)
        {
            HoaDonNapVi hdv = db.HoaDonNapVis.Find(id);
            var maHD = hdv.MaHD;
            var tenShop = hdv.HoSoShop.TenShop;
            var tenTKNH = hdv.HoSoShop.TenTKNH;
            var soTKNH = hdv.HoSoShop.SoTKNH;
            var soTienNap = hdv.TienNap;
            var ngayHoaDon = hdv.NgayHD;
            string ngay = string.Format("{0:dd/MM/yyyy HH:mm:ss}", ngayHoaDon);
            var trangThai = hdv.TrangThai;
            return Json(new
            {
                maHD,
                tenShop,
                tenTKNH,
                soTKNH,
                soTienNap,
                ngay,
                trangThai,
                status = true
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult XacNhanHoaDonVi(int id, int value)
        {
            HoaDonNapVi hdv = db.HoaDonNapVis.Find(id);
            bool status = false;
            string mess = string.Empty;
            if (hdv.TienNap == value)
            {
                hdv.HoSoShop.Vi += value;
                hdv.TrangThai = 1;
                db.SaveChanges();
                status = true;
                mess = "Hóa đơn được duyệt. " + value + " đã được chuyển vào tài khoản " + hdv.HoSoShop.TenShop + "";
            }
            else
            {
                hdv.TienNap = value;
                hdv.HoSoShop.Vi += value;
                hdv.TrangThai = 1;
                db.SaveChanges();
                status = true;
                mess = "Hóa đơn được duyệt. " + value + " đã được chuyển vào tài khoản " + hdv.HoSoShop.TenShop + "";
            }
            return Json(new
            {
                mess,
                status
            }, JsonRequestBehavior.AllowGet);
        }
        
        public JsonResult HienLyDoKH(int id)
        {
            KhachHang kh = db.KhachHangs.Find(id);
            var lydo = kh.GhiChu;
            return Json(new
            {
                lydo,
                status = true
            },JsonRequestBehavior.AllowGet);
        }

        public JsonResult HienLyDoShop(int id)
        {
            HoSoShop shop = db.HoSoShops.Find(id);
            var lydo = shop.GhiChu;
            return Json(new
            {
                lydo,
                status = true
            }, JsonRequestBehavior.AllowGet);
        }
    }
}