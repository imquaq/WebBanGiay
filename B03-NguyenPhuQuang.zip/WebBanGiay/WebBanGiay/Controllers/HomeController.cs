﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanGiay.Models;

namespace WebBanGiay.Controllers
{
    
    public class HomeController : Controller
    {
        QuanLyBanGiayEntities db = new QuanLyBanGiayEntities();
        // GET: Home
        public ActionResult Index()
        {
            return View(db.Giays.Take(9).ToList());
        }
        public ActionResult LienLac()
        {
            return View();
        }

        public ActionResult ThongTinShop()
        {
            return View();
        }
    }
}