﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using WebBanGiay.Models;

namespace WebBanGiay.Controllers
{
    public class ThongTinNguoiDungController : Controller
    {
        QuanLyBanGiayEntities db = new QuanLyBanGiayEntities();
        // GET: ThongTinNguoiDung
        public ActionResult ThongTinCaNhan()
        {
            if(Session["TaiKhoan"]==null)
            {
                return RedirectToAction("DangNhap", "NguoiDung");
            }
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            return View(kh);
        }
        
        [HttpPost]
        public ActionResult CapNhapMatKhau(FormCollection f)
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            KhachHang edit = db.KhachHangs.SingleOrDefault(p => p.MaKH == kh.MaKH);
            string MatKhau = MH.GetMD5( f["txtMKMoi"].ToString());
            edit.MatKhau = MatKhau;
            db.SaveChanges();
            Session["TaiKhoan"] = edit;
            return RedirectToAction("ThongTinCaNhan");
        }
        [HttpPost]
        public ActionResult CapNhapKhachHang( FormCollection f)
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            KhachHang edit = db.KhachHangs.SingleOrDefault(p => p.MaKH == kh.MaKH);
            string SDT = f["txtSDT"].ToString();
            string DC = f["txtDiaChi"].ToString();
            edit.DienThoai = SDT;
            edit.DiaChi = DC;
            db.SaveChanges();
            Session["TaiKhoan"] = edit;
            return RedirectToAction("ThongTinCaNhan");
        }
        [HttpPost]
        public ActionResult CapNhapEmail(FormCollection f)
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            KhachHang edit = db.KhachHangs.SingleOrDefault(p => p.MaKH == kh.MaKH);
            string email = f["txtEmailMoi"].ToString();
            edit.Email = email;
            edit.TrangThai = 0;
            db.SaveChanges();
            Session["TaiKhoan"] = edit;
            return RedirectToAction("KichHoatTaiKhoan");
        }
        [HttpPost]
        public JsonResult KTraEmail(string email)
        {
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" + @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" + @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            Regex re = new Regex(strRegex);
            bool check;
            if (re.IsMatch(email))
            {
                check = true;
            }
            else check = false;
            return Json(new { status = check });
        }
        public JsonResult KTraMK(string MK)
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            MK = MH.GetMD5(MK);
            bool check=true;
            if (kh.MatKhau!=MK)
            {
                check = false;
            }
            return Json(new { status = check });
        }
        [HttpGet]
        public ActionResult KichHoatTaiKhoan()
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap", "NguoiDung");
            }
            if (kh.TrangThai ==1)
            {
                return RedirectToAction("Index", "Home");
            }
            if(Session["MaKichHoat"]==null || Session["MaKichHoat"]=="")
            {
                ViewBag.ThongBao = "Mã kích hoạt đã hết thời hạn, mời bạn nhấm vào nút gửi lại mã để tiếp tục kích hoạt tài khoản";
            }
            return View();
        }
        [HttpPost]
        public ActionResult KichHoatTaiKhoan(FormCollection f)
        {
            string MaKH = f["txtMaOTP"].ToString();
            string MaKH2 = Session["MaKichHoat"] as string;
            if (MaKH == MaKH2)
            {
                KhachHang kh = Session["TaiKhoan"] as KhachHang;
                KhachHang edit = db.KhachHangs.SingleOrDefault(p => p.MaKH == kh.MaKH);
                edit.TrangThai = 1;
                db.SaveChanges();
                Session["TaiKhoan"] = edit;
                Session["MaKichHoat"] = null;
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.ThongBao = "Mã kích hoạt chưa chính xác";
                return View();
            }
        }
        [HttpPost]
        public JsonResult GuiMaKichHoat()
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            return Json(new { status=GuiMaKichHoat(kh)});
        }
        public string TaoMaKichHoat()
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < 5; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            return builder.ToString();
        }
        public bool GuiMaKichHoat(KhachHang kh)
        {
            string MaKichHoat = TaoMaKichHoat();
            Session["MaKichHoat"] = MaKichHoat;
            StringBuilder Body = new StringBuilder();
            Body.Append("<h4>Mã kích hoạt tài khoản</h4>");
            Body.Append("<br/>");
            Body.Append("<p>Mã:"+MaKichHoat+"</p>");
            Body.Append("<br/>");
            Body.Append("<p>Nguồn khách:Website bán giày 5 thành viên</p><br/><p>Google.com</p>");
            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add(kh.Email);
                mail.From = new MailAddress("lhthinhcntt@gmail.com");
                mail.Subject = "Kích hoạt tài khoản";
                mail.Body = Body.ToString();// phần thân của mail ở trên
                mail.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = new System.Net.NetworkCredential("lhthinhcntt@gmail.com", "220598lht");// tài khoản Gmail của bạn
                smtp.EnableSsl = true;
                smtp.Send(mail);
                return true;
            }catch (Exception ex)
            {
                return false;
            }
        }
    }
}