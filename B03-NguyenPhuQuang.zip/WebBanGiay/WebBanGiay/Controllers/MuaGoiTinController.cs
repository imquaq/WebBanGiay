﻿using System;
using PagedList;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanGiay.Models;

namespace WebBanGiay.Controllers
{
    public class MuaGoiTinController : Controller
    {
        QuanLyBanGiayEntities db = new QuanLyBanGiayEntities();
        // GET: MuaGoiTin
        public ActionResult MuaGoiTin(int? page)
        {
            int pageNumber = (page ?? 1);
            int pageSize = 10;
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap","ShopAdmin");
            }
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            if (shop == null)
            {
                return RedirectToAction("DangKy", "ShopAdmin");
            }
            ViewBag.Shop = shop;
            return View(db.GoiTins.Where(p=>p.TrangThai==1).ToList().ToPagedList(pageNumber, pageSize));
        }
        public ActionResult HDGoiTin(int? page)
        {

            int pageNumber = (page ?? 1);
            int pageSize = 20;
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap", "ShopAdmin");
            }
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            if (shop == null)
            {
                return RedirectToAction("DangKy", "ShopAdmin");
            }
            ViewBag.Shop = shop;
            return View(db.HoaDonGoiTins.Where(p=>p.MaShop==shop.MaShop).ToList().ToPagedList(pageNumber, pageSize));
        }
        public ActionResult LichSuNap(int? page)
        {

            int pageNumber = (page ?? 1);
            int pageSize = 20;
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap", "ShopAdmin");
            }
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            if (shop == null)
            {
                return RedirectToAction("DangKy", "ShopAdmin");
            }
            ViewBag.Shop = shop;
            return View(db.HoaDonNapVis.Where(p => p.MaShop == shop.MaShop).ToList().ToPagedList(pageNumber, pageSize));
        }
        public JsonResult MuaGoi(int MaGoi)
        {

            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            GoiTin goi = db.GoiTins.SingleOrDefault(p => p.MaGoi == MaGoi);
            HoaDonGoiTin hd = new HoaDonGoiTin();
            hd.MaGoi = MaGoi;
            hd.MaShop = shop.MaShop;
            hd.NgayHD = DateTime.Now.Date;
            db.HoaDonGoiTins.Add(hd);
            db.SaveChanges();
            shop.SoTinTon += goi.SoLuong;
            shop.Vi -= goi.Gia;
            db.SaveChanges();
            int? sl1 = shop.SoTinTon;
            int? vi1 =Convert.ToInt32( shop.Vi);
            return Json(new { sl= sl1,vi= vi1 }, JsonRequestBehavior.AllowGet);

        }
        [HttpGet]
        public ActionResult NapViTien()
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap", "ShopAdmin");
            }
            
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            if (shop == null)
            {
                return RedirectToAction("DangKy", "ShopAdmin");
            }
            ViewBag.Shop = shop;
            return View(shop);
        }
        [HttpPost]
        public ActionResult NapViTien(FormCollection f, HttpPostedFileBase fileUpLoad)
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            HoaDonNapVi hd = new HoaDonNapVi();
            hd.MaShop = shop.MaShop;
            hd.NgayHD = DateTime.Now.Date;
            hd.TienNap =Convert.ToInt32( f["TienNap"].ToString());
            hd.TrangThai = 0;
            db.HoaDonNapVis.Add(hd);
            db.SaveChanges();
            fileUpLoad.SaveAs(Server.MapPath("~/AnhHD/" + hd.MaHD + ".jpg"));
            return View(shop);
        }
    }
}