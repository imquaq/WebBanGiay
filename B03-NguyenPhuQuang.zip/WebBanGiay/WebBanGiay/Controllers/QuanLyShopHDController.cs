﻿using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanGiay.Models;

namespace WebBanGiay.Controllers
{
    public class QuanLyShopHDController : Controller
    {
        QuanLyBanGiayEntities db = new QuanLyBanGiayEntities();
        // GET: QuanLyShopHD
        public ActionResult DanhSachHD( int? page)
        {
            int pageNumber = (page ?? 1);
            int pageSize = 20;
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap", "ShopAdmin");
            }
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            if (shop == null)
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.Shop = shop;
            return View(db.DonHangs.ToList().Where(p => p.MaShop == kh.MaKH).OrderBy(p => p.MaDH).OrderBy(p=>p.TinhTrangGiaoHang).ToPagedList(pageNumber, pageSize));

        }
        [HttpPost]
        public JsonResult CapNhapGiaoHang(int MaDH)
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            DonHang dh = db.DonHangs.SingleOrDefault(p => p.MaDH == MaDH && p.MaShop==kh.MaKH);
            dh.TinhTrangGiaoHang = 1;
            db.SaveChanges();
            return Json(new { status = true}, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult CapNhapHoanThanh(int MaDH)
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            DonHang dh = db.DonHangs.SingleOrDefault(p => p.MaDH == MaDH && p.MaShop == kh.MaKH);
            dh.TinhTrangGiaoHang = 2;
            dh.NgayGiao = DateTime.Now;
            db.SaveChanges();
            return Json(new { status = true }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult CapNhapHuy(int MaDH)
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            DonHang dh = db.DonHangs.SingleOrDefault(p => p.MaDH == MaDH && p.MaShop == kh.MaKH);
            dh.TinhTrangGiaoHang = 3;
            dh.NgayGiao = DateTime.Now;
            db.SaveChanges();
            return Json(new { status = true }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult LoadChiTietDH(int MaDH)
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            List<ChiTietDonHang> lst= db.ChiTietDonHangs.Where(p => p.MaDH == MaDH && p.Giay.MaShop == kh.MaKH).ToList();
            List<CTDH> lst2 = new List<CTDH>();
            foreach (var item in lst)
            {
                CTDH ct = new CTDH();
                ct.MaGiay = item.MaGiay;
                ct.TenGiay = item.Giay.TenGiay;
                ct.SL = item.SoLuong;
                ct.Size = item.SizeGiay;
                lst2.Add(ct);
            }
            return Json(lst2, JsonRequestBehavior.AllowGet);
        }
    }
}