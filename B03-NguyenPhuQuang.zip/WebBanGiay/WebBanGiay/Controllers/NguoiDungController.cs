﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.Mvc;
using PagedList;
using PagedList.Mvc;
using WebBanGiay.Models;

namespace WebBanGiay.Controllers
{
    public class NguoiDungController : Controller
    {
        QuanLyBanGiayEntities db = new QuanLyBanGiayEntities();
        // GET: NguoiDung
        [HttpGet]
        public ActionResult DangNhap()
        {
            return View();
        }
        [HttpPost]
        public ActionResult DangNhap(FormCollection f)
        {
            string sTaiKhoan = f.Get("txtTaiKhoan").ToString();
            string sMatKhau =MH.GetMD5( f["txtMatKhau"].ToString());
            KhachHang kh = db.KhachHangs.SingleOrDefault(p => p.TaiKhoan == sTaiKhoan && p.MatKhau ==  sMatKhau);
            if (kh != null)
            {
                Session["TaiKhoan"] = kh;
                if (kh.TrangThai == 1)
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    return RedirectToAction("KichHoatTaiKhoan", "ThongTinNguoiDung");
                }
            }
            ViewBag.ThongBao = "Tài khoản hoặc mật khẩu không đúng!";
            return View();
        }
        [HttpGet]
        public ActionResult DangKy()
        {
            return View();
        }
        [HttpPost]
        public ActionResult DangKy(DKKhachHang dk)
        {
            KhachHang tk = db.KhachHangs.ToList().Find(p => p.TaiKhoan == dk.TaiKhoan);
            if (tk != null)
            {
                ViewBag.ThongBao = "Tài khoản này đã có người sử dụng";
                return View();
            }
            if (ModelState.IsValid)
            {
                KhachHang kh = new KhachHang();
                kh.HoTen = dk.HoTen;
                kh.DiaChi = dk.DiaChi;
                kh.DienThoai = dk.DienThoai;
                kh.Email = dk.Email;
                kh.TaiKhoan = dk.TaiKhoan;
                kh.MatKhau =MH.GetMD5( dk.MatKhau);
                kh.TrangThai = 0;
                kh.Quyen = 0;
                db.KhachHangs.Add(kh);
                db.SaveChanges();
                return RedirectToAction("DangNhap");
            }
            return View();
        }
        public ActionResult KTraDangNhapPartial()
        {
            return PartialView();
        }
        
        public ActionResult DangXuat()
        {
            Session["TaiKhoan"] = null;
            return RedirectToAction("Index","Home");
        }
        public ActionResult HDMuaHang(int? page)
        {
            
            int pageNumber = (page ?? 1);
            int pageSize = 20;
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }
            ViewBag.HoaDonTong = db.DonHangTongs.Where(p => p.MaKH == kh.MaKH).ToList();
            return View(db.DonHangs.Where(p => p.DonHangTong.MaKH == kh.MaKH).ToList().ToPagedList(pageNumber, pageSize));
        }
        public ActionResult ChiTietDH(int MaDH,int MaShop)
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }
            DonHang dh = db.DonHangs.SingleOrDefault(p => p.MaDH == MaDH && p.MaShop == MaShop);
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == MaShop);
            ViewBag.Shop = shop;
            Rating rate = db.Ratings.SingleOrDefault(p => p.MaDonHang == dh.MaDonHang);
            ViewBag.MaHD = dh.MaDonHang;
            if (dh.TinhTrangGiaoHang==2 && rate == null)
            {
                ViewBag.Check = 1;
            }
            else 
                ViewBag.Check = 0;
            return View(db.ChiTietDonHangs.Where(p => p.MaDH == MaDH && p.Giay.MaShop == MaShop).ToList());
        }
        [HttpPost]
        public ActionResult RatingHD(int MaHD, FormCollection f)
        {
            DonHang dh = db.DonHangs.SingleOrDefault(p => p.MaDonHang == MaHD );

            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == dh.MaShop);
            Rating rate = new Rating();
            rate.MaDonHang = MaHD;
            rate.MaShop = dh.MaShop;
            rate.SoRating = Convert.ToInt16(f["SoRate"].ToString());
            rate.GhiChu = f["txtGhiChu"].ToString();
            db.Ratings.Add(rate);
            db.SaveChanges();
            var a = db.Ratings.Where(p => p.MaShop == shop.MaShop).ToList();
            var b= Math.Round((double)a.Average(p => p.SoRating), 1);
            shop.Rating = b;
            db.SaveChanges();
            return RedirectToAction("ChiTietDH",new { MaDH=dh.MaDH,@MaShop=dh.MaShop});
        }
        [HttpPost]
        public JsonResult KTraRating(int MaHD)
        {
            Rating rate = db.Ratings.SingleOrDefault(p => p.MaDonHang == MaHD);
            if (rate == null)
            {
                return Json(new { status = true });
            }
            return Json(new { status = false });
        }
        [HttpGet]
        public ActionResult QuenMK()
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh != null)
            {
                return RedirectToAction("Index","Home");
            }
            return View();
        }
        [HttpPost]
        public ActionResult QuenMK( FormCollection f)
        {
            string tk = f["txtTK"].ToString();
            KhachHang kh = db.KhachHangs.SingleOrDefault(p => p.TaiKhoan == tk);
            if (kh == null)
            {
                ViewBag.ThongBao = "Tài khoản không tồn tại";
                return View();
            }
            GuiMatKhauMoi(kh);
            return RedirectToAction("DangNhap");
        }
        public string TaoMatKhauMoi()
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < 6; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            return builder.ToString();
        }
        public void GuiMatKhauMoi(KhachHang kh)
        {
            string mk = TaoMatKhauMoi();
            kh.MatKhau = MH.GetMD5(mk);
            db.SaveChanges();
            StringBuilder Body = new StringBuilder();
            Body.Append("<h4>Mật khẩu tài khoản</h4>");
            Body.Append("<br/>");
            Body.Append("<p>Mật khẩu:" + mk + "</p>");
            Body.Append("<br/>");
            Body.Append("<p>Nguồn khách:Website bán giày 5 thành viên</p><br/><p>Google.com</p>");
            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add(kh.Email);
                mail.From = new MailAddress("lhthinhcntt@gmail.com");
                mail.Subject = "Kích hoạt tài khoản";
                mail.Body = Body.ToString();// phần thân của mail ở trên
                mail.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = new System.Net.NetworkCredential("lhthinhcntt@gmail.com", "220598lht");// tài khoản Gmail của bạn
                smtp.EnableSsl = true;
                smtp.Send(mail);
            }
            catch (Exception ex)
            {
            }
        }
    }
}