﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanGiay.Models;
using PagedList;
using PagedList.Mvc;
using System.IO;
using Antlr.Runtime;

namespace WebBanGiay.Controllers
{
    public class QuanLyShopAdminController : Controller
    {
        QuanLyBanGiayEntities db = new QuanLyBanGiayEntities();
        // GET: QuanLyShopAdmin
        public ActionResult DanhSachGiay(int? page)
        {
            int pageNumber=(page ?? 1);
            int pageSize=10;
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap", "ShopAdmin");
            }
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            if(shop==null)
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.Shop = shop;
            return View(db.Giays.ToList().Where(p=>p.MaShop==kh.MaKH).OrderBy(p=>p.MaGiay).ToPagedList(pageNumber,pageSize));
        }
        [HttpGet]
        public ActionResult ThemMoiSanPham()
        {

            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            ViewBag.Shop = shop;
            //đưa dữ liệu vào droplist
            ViewBag.MaHang = new SelectList( db.HangGiays.Where(p => p.LevelHang == 1).OrderBy(p=>p.TenHang).ToList(),"MaHangGiay","TenHang");
            return View();
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult ThemMoiSanPham(FormCollection f,HttpPostedFileBase fileUpLoad)
        {
            
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap", "ShopAdmin");
            }
            Giay giay = new Giay();
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            ViewBag.Ten = shop.TenShop;
            giay.TenGiay = f["txtTen"].ToString();
            giay.GiaBan =Convert.ToInt64( f["txtGia"].ToString());
            giay.MaHang = Convert.ToInt16( f["MaHang"].ToString());
            giay.Sale = Convert.ToInt16( f["txtSale"].ToString());
            giay.MoTa = f["MoTa"].ToString();
            giay.NgayCapNhap = DateTime.Now;
            giay.MaShop = kh.MaKH;
            giay.TrangThai = 1;
            //Lưu tên của file
            if (fileUpLoad==null)
            {
                ViewBag.ThongBao = "Chưa chọn ảnh";
                ViewBag.MaHang = new SelectList(db.HangGiays.Where(p => p.LevelHang == 1).OrderBy(p => p.TenHang).ToList(), "MaHangGiay", "TenHang");

                return View();
            }
            
             if (ModelState.IsValid)
            {
                db.Giays.Add(giay);
                db.SaveChanges();
                Directory.CreateDirectory(Server.MapPath("~/HinhAnhGiay/Ma" + giay.MaGiay));
                //lưu đường dẫn file
                var path = Path.Combine(Server.MapPath("~/HinhAnhGiay/AnhGiay/"), giay.MaGiay.ToString()+".jpg");
                fileUpLoad.SaveAs(path);
            }
            shop.SoTinTon--;
            db.SaveChanges();
            ViewBag.MaHang = new SelectList(db.HangGiays.Where(p => p.LevelHang == 1).OrderBy(p => p.TenHang).ToList(), "MaHangGiay", "TenHang");

            return RedirectToAction("ThemChiTietGiay",new { @MaGiay=giay.MaGiay});
        }
        [HttpGet]
        public ActionResult ThemChiTietGiay(int MaGiay)
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            ViewBag.Shop = shop;
            Giay giay = db.Giays.SingleOrDefault(p => p.MaGiay == MaGiay);
            if(giay==null)
            {
                Response.StatusCode = 404;
                return null;
            }
            if (giay.ChiTietGiays.Count() != 0)
            {
                return RedirectToAction("DanhSachGiay");
            }
            return View(giay);
        }
        [HttpPost]
        public JsonResult ThemSize(int MaGiay,int size,int sl)
        {
            Giay giay = db.Giays.SingleOrDefault(p => p.MaGiay == MaGiay);
            bool check = true;
            if (giay == null)
            {
                check = false;
            }
            else
            {
                ChiTietGiay ct = new ChiTietGiay();
                ct.Size = size;
                ct.MaGiay = MaGiay;
                ct.SoLuong = sl;
                db.ChiTietGiays.Add(ct);
                db.SaveChanges();
            }
            return Json(new { status = check });

        }
        [HttpPost]
        public JsonResult LoadSize(int MaGiay)
        {
            List<ChiTietGiay> lst = db.ChiTietGiays.Where(p=>p.MaGiay==MaGiay).ToList();
            List<ChiTietGiay> lst1 = new List<ChiTietGiay>();
            foreach (var item in lst)
            {
                lst1.Add(new ChiTietGiay { Size = item.Size, SoLuong = item.SoLuong, MaGiay = item.MaGiay });
            }
            return Json(lst1, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult LoadChiTiet(int MaGiay)
        {
            Giay giay = db.Giays.SingleOrDefault(p => p.MaGiay == MaGiay);
            Giay a = new Giay();
            a.MaGiay = giay.MaGiay;
            a.TenGiay = giay.TenGiay;
            a.MoTa = giay.MoTa;
            string c = giay.NgayCapNhap.Value.ToShortDateString();
            string b = giay.HangGiay.TenHang;

            return Json(new { status =a,b=b,c=c }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult LoadAnh(int MaGiay)
        {
            List<ChiTietAnhGiay> lst = db.ChiTietAnhGiays.Where(p => p.MaGiay == MaGiay).ToList();
            List<ChiTietAnhGiay> lst1 = new List<ChiTietAnhGiay>();
            foreach (var item in lst)
            {
                lst1.Add(new ChiTietAnhGiay { MaCTAnh = item.MaCTAnh,  MaGiay = MaGiay });
            }
            return Json(lst1, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult ThemCTAnh(int MaGiay, HttpPostedFileBase file)
        {
            ChiTietAnhGiay ct = new ChiTietAnhGiay();
            ct.MaGiay = MaGiay;
            db.ChiTietAnhGiays.Add(ct);
            db.SaveChanges();
            var path = Path.Combine(Server.MapPath("~/HinhAnhGiay/Ma"+MaGiay+"/")+ct.MaCTAnh + ".jpg");
            file.SaveAs(path);
            return Json(new {status = true}, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult LuuSL(int MaGiay,int size, int sl)
        {
            ChiTietGiay ct = db.ChiTietGiays.SingleOrDefault(p=>p.MaGiay==MaGiay && p.Size==size);
            if (ct == null)
                return Json(new { status = false }, JsonRequestBehavior.AllowGet);
            ct.SoLuong = sl;
            db.SaveChanges();
            return Json(new { status = true }, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public ActionResult ChinhSuaSP(int MaGiay )
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            ViewBag.Shop = shop;
            Giay giay = db.Giays.SingleOrDefault(p => p.MaGiay == MaGiay);
            if (giay == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            ViewBag.Size = db.ChiTietGiays.Where(p => p.MaGiay == MaGiay).ToList();
            return View(giay);
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult ChinhSuaSP(int MaGiay, FormCollection f)
        {
            Giay giay = db.Giays.SingleOrDefault(p => p.MaGiay == MaGiay);
            giay.NgayCapNhap = DateTime.Now;
            giay.Sale =Convert.ToInt16( f["txtSale"].ToString());
            giay.MoTa = f["MoTa"].ToString();
            db.SaveChanges();
            return RedirectToAction("DanhSachGiay");
        }
        [HttpPost]
        public JsonResult CapNhapTrangThai(int MaGiay)
        {
            Giay giay = db.Giays.SingleOrDefault(p => p.MaGiay == MaGiay);
            string b="" ;
            bool check = true;
            if (giay.TrangThai == 2)
            {
                b = giay.TrangThaiGiay.TenTTGiay;
                giay.TrangThai = 3;
                check = false;
            }
            else if (giay.TrangThai == 3)
            {
                b = giay.TrangThaiGiay.TenTTGiay;
                giay.TrangThai = 2;
                check = true;
            }
            db.SaveChanges();
            string a = giay.TrangThaiGiay.TenTTGiay;
            return Json(new {status=check, status1 = a,satus2=b}, JsonRequestBehavior.AllowGet);
        }
    }
}