﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanGiay.Models;
using PagedList.Mvc;
using PagedList;

namespace WebBanGiay.Controllers
{
    public class ShopAdminController : Controller
    {
        // GET: ShopAdmin
        QuanLyBanGiayEntities db = new QuanLyBanGiayEntities();
        public ActionResult CheckShop()
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            if (shop != null)
            {
                return RedirectToAction("ThongTinShop");
            }
            return View();
        }
        [HttpGet]
        public ActionResult DangKy()
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            if (shop != null)
            {
                return RedirectToAction("ThongTinShop");
            }
            return View();
        }
        public ActionResult DanhSachPhanHoi(int? page)
        {
            int pageNumber = (page ?? 1);
            int pageSize = 10;
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            if (shop == null)
            {
                return RedirectToAction("CheckShop");
            }

            ViewBag.Shop = shop;
            return View(db.Ratings.Where(p => p.MaShop == shop.MaShop).OrderBy(p => p.MaDonHang).ToList().ToPagedList(pageNumber, pageSize));
        }
        public ActionResult DangXuat()
        {
            Session["TaiKhoan"] = null;
            return RedirectToAction("DangNhap");
        }
        [HttpPost]
        public ActionResult DangKy(FormCollection f,HttpPostedFileBase fileUpLoad)
        {
            HoSoShop shop = new HoSoShop();
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            shop.MaShop = kh.MaKH;
            shop.TenShop = f["txtTen"].ToString();
            shop.DiaChiShop= f["txtDC"].ToString();
            shop.SDTShop = f["txtSDT"].ToString();
            shop.Vi = 0;
            shop.TenTKNH = f["txtTenTK"].ToString();
            shop.SoTKNH = f["txtSoTK"].ToString();
            shop.TrangThai = 1;
            db.HoSoShops.Add(shop);
            db.SaveChanges();
            fileUpLoad.SaveAs(Server.MapPath("~/AnhCMND/" + shop.MaShop+".jpg"));
            return RedirectToAction("ThongTinShop");
        }
        [HttpGet]
        public ActionResult DangNhap()
        {
            return View();
        }
        [HttpPost]
        public ActionResult DangNhap( FormCollection f)
        {
            string tk = f["txtTK"].ToString();
            string mk =MH.GetMD5( f["txtMK"].ToString());
            KhachHang kh = db.KhachHangs.SingleOrDefault(p => p.TaiKhoan == tk && p.MatKhau == mk);
            if (kh == null)
            {
                ViewBag.ThongBao = "Sai tài khoản hoặc mật khẩu";
                return View();
            }
            Session["TaiKhoan"] = kh;
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            if (shop == null)
            {
                return RedirectToAction("CheckShop");
            }
            return RedirectToAction("ThongTinShop");
        }
        [HttpGet]
        public ActionResult ThongTinShop()
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            if (kh == null)
            {
                return RedirectToAction("DangNhap");
            }
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            if (shop == null)
            {
                return RedirectToAction("DangKy");
            }
            var a = db.Ratings.Where(p => p.MaShop == shop.MaShop).ToList();
            List<DonHang> lsdh = db.DonHangs.Where(p => p.TinhTrangGiaoHang == 2 &&p.MaShop==shop.MaShop ).ToList();
            int? tam = 0;
            foreach (var i in lsdh)
            {
                tam += db.ChiTietDonHangs.Where(p => p.MaDH == i.MaDH && p.Giay.MaShop == i.MaShop).Sum(p => p.SoLuong);
            }
            ViewBag.TongDonHang = lsdh.Count();
            ViewBag.TongSP = db.Giays.Where(p=>p.MaShop==shop.MaShop && p.TrangThai==2).Count();
            ViewBag.TongDoangThu= lsdh.Sum(p => p.TongTien);
            ViewBag.TongSanPhamBanDuoc = tam;
            ViewBag.Shop = shop;
            return View(shop);
        }
        [HttpPost]
        public ActionResult ThongTinShop(FormCollection f)
        {
            KhachHang kh = Session["TaiKhoan"] as KhachHang;
            HoSoShop shop = db.HoSoShops.SingleOrDefault(p => p.MaShop == kh.MaKH);
            shop.TenShop = f["txtTen"].ToString();
            shop.DiaChiShop = f["txtDC"].ToString();
            shop.SDTShop = f["txtSDT"].ToString();
            shop.TenTKNH = f["txtTenTK"].ToString();
            shop.SoTKNH = f["txtSoTK"].ToString();
            db.SaveChanges();
            ViewBag.Shop = shop;
            return View(shop);
        }
        public JsonResult ThemAnhCMND(HttpPostedFileBase file)
        {
            file.SaveAs(Server.MapPath("~/TestAnh/" + file.FileName));
            string a= "/TestAnh/" + file.FileName;
            return Json(a, JsonRequestBehavior.AllowGet);
        }
    }
}