﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanGiay.Models;

namespace WebBanGiay.Controllers
{
    public class HangGiayController : Controller
    {
        QuanLyBanGiayEntities db = new QuanLyBanGiayEntities();
        
        // GET: Giay
        public ActionResult HangGiayPartial()
        {
            List<HangGiay> lst = db.HangGiays.Where(p=>p.LevelHang==0).ToList();
            return PartialView(lst);
        }
        public ActionResult HangGiay2Partial(int iMaHang)
        {
            List<HangGiay> lst = db.HangGiays.Where(p => p.MaHang2 == iMaHang).ToList();
            return PartialView(lst);
        }
    }
}