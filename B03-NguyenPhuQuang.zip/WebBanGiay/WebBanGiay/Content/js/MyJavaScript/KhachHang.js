﻿var user = {
    init: function () {
        user.registerEvents();
    },
    registerEvents: function () {
        $('.btn-active').off('click').on('click', function (e) {
            e.preventDefault();
            $('#modal-lydo1').modal('show');
            var id = $(this).data('id');
            $('#btn-vohieuhoa').off('click').on('click', function () {
                user.UpdateTrangThai(id);
            });
        });

        $('.btn-lydo').off('click').on('click', function (e) {
            e.preventDefault();
            $('#modal-lydo2').modal('show');
            var id = $(this).data('id');
            user.HienLyDo(id);
            $('#btn-kichhoat').off('click').on('click', function () {
                user.UpdateTrangThai2(id);
            });
        });

        $('.btn-add').off('click').on('click', function () {
            $('#modalAdd').modal('show');
        });
        $('#btn-save-add').off('click').on('click', function () {
            user.LuuThongTinKhachHang();
        });

    },
    UpdateTrangThai: function (id) {
        var lydo = $('#LyDo1').val();
        $.ajax({
            url: '/WebMaster/UpdateTrangThaiKH',
            data: {
                id: id,
                lydo: lydo
            },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status) {
                    alert(response.mess);
                    location.reload();
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },

    UpdateTrangThai2: function (id) {
        var lydo = $('#LyDo2').val();
        $.ajax({
            url: '/WebMaster/UpdateTrangThaiKH',
            data: {
                id: id,
                lydo: lydo
            },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status) {
                    alert(response.mess);
                    location.reload();
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },

    LuuThongTinKhachHang: function () {

        var ten = $('#Ten').val();
        var soDT = $('#SoDT').val();
        var email = $('#Email').val();
        var dc = $('#DC').val();
        var tenTK = $('#TenTK').val();
        var matKhau = $('#MatKhau').val();
        var quyen = 0;
        var tt = 1;
        var kh = {
            HoTen: ten,
            DienThoai: soDT,
            Email: email,
            DiaChi: dc,
            TaiKhoan: tenTK,
            MatKhau: matKhau,
            Quyen: quyen,
            TrangThai: tt
        };
        $.ajax({
            url: '/WebMaster/LuuKhachHang',
            data: {
                strkh: JSON.stringify(kh)
            },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status) {
                    alert(response.message);
                    $('#modalAdd').modal('hide');
                    location.reload();
                }
                else {
                    alert(response.message);
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },

    HienLyDo: function (id) {
        $.ajax({
            url: '/WebMaster/HienLyDoKH',
            data: {
                id: id
            },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status) {
                    $('#LyDo2').val(response.lydo);
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    }
};
user.init();