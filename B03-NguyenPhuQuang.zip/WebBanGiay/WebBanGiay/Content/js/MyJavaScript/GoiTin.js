﻿var user = {
    init: function () {
        user.registerEvents();
    },
    registerEvents: function () {
        
        $('.btn-edit').off('click').on('click', function () {
            $('#modalEdit').modal('show');
            var id = $(this).data('id');
            user.LayThongTinGoi(id);
        });
        $('.btn-add').off('click').on('click', function () {
            $('#modalAdd').modal('show');
        });
        $('#btn-save-add').off('click').on('click', function () {
            user.LuuGoiMoi();
        });
        $('.btn-delete').off('click').on('click', function () {
            var id = $(this).data('id');
            user.XoaGoiTin(id);
        });
        $('#btn-save').off('click').on('click', function () {
            user.LuuThongTinGoi();
        });
        
    },


    LayThongTinGoi: function (id) {
        $.ajax({
            url: '/WebMaster/LayGoi',
            data: { id:id },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status) {
                    $('#hiID').val(response.maGoi);
                    $('#Name').val(response.tenGoi);
                    $('#Number').val(response.soLuong);
                    $('#Price').val(response.gia);
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },

    LuuThongTinGoi: function () {

        var name = $('#Name').val();
        var number = $('#Number').val();
        var price = $('#Price').val();
        var id = $('#hiID').val();
        var gt = {
            TenGoi: name,
            SoLuong: number,
            Gia: price,
            MaGoi: id
        };
        $.ajax({
            url: '/WebMaster/LuuGoi',
            data: {
                strgt: JSON.stringify(gt)
            },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status === true) {
                    alert('Lưu thành công');
                    $('#modalEdit').modal('hide');
                    location.reload();
                }
                else {
                    alert(response.message);
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },

    LuuGoiMoi: function () {

        var name = $('#txtName').val();
        var number = $('#txtNumber').val();
        var price = $('#txtPrice').val();
        var id = $('#hiIDa').val();
        var gt = {
            TenGoi: name,
            SoLuong: number,
            Gia: price,
            MaGoi: id
        };
        $.ajax({
            url: '/Home/LuuGoi',
            data: {
                strgt: JSON.stringify(gt)
            },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status === true) {
                    alert('Lưu thành công');
                    $('#modalEdit').modal('hide');
                    location.reload();
                }
                else {
                    alert(response.message);
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },
    

    XoaGoiTin: function (id) {
        $.ajax({
            url: '/WebMaster/UpdateGoiTin',
            data: { id: id },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status) {
                    alert(response.mess);
                    location.reload();
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    }
};
user.init();