﻿var user = {
    init: function () {
        user.registerEvents();
    },
    registerEvents: function () {
        $('.btn-view').off('click').on('click', function () {
            $('#myModal').modal('show');
            var id = $(this).data('id');
            user.LayThongTinGiay(id);
            user.loadAnh(id);
            user.loadSize(id);
        });

        $('.btn-accept').off('click').on('click', function (e) {
            e.preventDefault();
            var id = $(this).data('id');
            var value = 2;
            user.UpdateTrangThai(id, value);
        });
        $('.btn-deny').off('click').on('click', function (e) {
            e.preventDefault();
            var id = $(this).data('id');
            var value = 0;
            user.UpdateTrangThai(id, value);
        });

        $('.btn-update').off('click').on('click', function (e) {
            e.preventDefault();
            var id = $(this).data('id');
            user.AnHienGiay(id);
        });
    },

    AnHienGiay: function (id) {
        $.ajax({
            url: '/WebMaster/AnHienGiay',
            data: {
                id: id
            },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status) {
                    alert(response.message);
                    location.reload();
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },

    UpdateTrangThai: function (id, value) {
        var btn = $(this);
        $.ajax({
            url: '/WebMaster/UpdateTrangThaiGiay',
            data: {
                id: id,
                value: value
            },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status) {
                    alert(response.message);
                    location.reload();
                }
                else {
                    alert("Lỗi");
                    location.reload();
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },

    LayThongTinGiay: function (id) {
        $.ajax({
            url: '/WebMaster/LayThongTinGiay',
            data: { id: id },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status === true)
                {
                    $('#AnhGiay').attr('src', '/HinhAnhGiay/AnhGiay/' + id + '.jpg');
                    $('#txtTenShop').val(response.tenShop);
                    $('#txtTenHang').val(response.tenHang);
                    $('#txtTenSanPham').val(response.tenSanPham);
                    $('#txtGiaBan').val(response.giaBan);
                    $('#txtMoTa').val(response.moTa);
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },
    loadSize: function (id) {
            $.ajax({
                url: '/QuanLyShopAdmin/LoadSize',
                data: { MaGiay: id },
                dataType: "json",
                type: "POST",
                success: function (data) {
                    var html = '';
                    $.each(data, function (i, item) {
                        html += '<tr>'
                        html += '<td>' + item.Size + '</td>'
                        html += '<td>' + item.SoLuong + '</td>'
                        html += '</tr>'
                    });
                    $('#Size').html(html);
                }, Error: function (ex) {
                    var r = jQuery.parseJSON(response.responseText);
                    alert("Message: " + r.Message);
                    alert("StackTrace: " + r.StackTrace);
                    alert("ExceptionType: " + r.ExceptionType);
                }
            })
        },
    loadAnh: function (id) {
        $.ajax({
            url: '/QuanLyShopAdmin/LoadAnh',
            data: { MaGiay: id},
            dataType: "json",
            type: "POST",
            success: function (data) {
                var html = '';
                html += '<tr>'
                html += '<td colspan="2">'
                $.each(data, function (i, item) {
                    html += '<img src="/HinhAnhGiay/Ma' + id + '/' + item.MaCTAnh + '.jpg" width="300"/>'
                });

                html += '</td>'
                html += '</tr>'
                $('#AnhMoTa').html(html);
            },Error: function (ex) {
                var r = jQuery.parseJSON(response.responseText);
                alert("Message: " + r.Message);
                alert("StackTrace: " + r.StackTrace);
                alert("ExceptionType: " + r.ExceptionType);
            }
        })
    },
};
user.init();