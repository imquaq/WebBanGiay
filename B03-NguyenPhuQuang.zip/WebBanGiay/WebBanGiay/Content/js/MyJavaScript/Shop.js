﻿var user = {
    init: function () {
        user.registerEvents();
    },
    registerEvents: function () {
        $('.btn-active').off('click').on('click', function (e) {
            e.preventDefault();
            $('#modal-lydo1').modal('show');
            var id = $(this).data('id');
            $('#btn-vohieuhoa').off('click').on('click', function () {
                user.UpdateTrangThai(id);
            });
        });

        $('.btn-lydo').off('click').on('click', function (e) {
            e.preventDefault();
            $('#modal-lydo2').modal('show');
            var id = $(this).data('id');
            user.HienLyDo(id);
            $('#btn-kichhoat').off('click').on('click', function () {
                user.UpdateTrangThai2(id);
            });
        });

        $('.btn-view').off('click').on('click', function () {
            var id = $(this).data('id');
            var x = $(this).data('stt');
            if (x === 1)
                $('#modal-view2').modal('show');
            else
                $('#modal-view').modal('show');
            user.LayThongTinHoaDonVi(id);

        });

        $('.btn-accept').off('click').on('click', function () {
            var id = $('#hiID').val();
            var value = $('#SoTienNap').val();
            user.XacNhanHoaDon(id, value);
        });
        
    },

    UpdateTrangThai: function (id) {
        var lydo = $('#LyDo1').val();
        $.ajax({
            url: '/WebMaster/UpdateTrangThaiShop',
            data: {
                id: id,
                lydo: lydo
            },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status) {
                    alert(response.mess);
                    location.reload();
                }
                else {
                    alert(response.mess);
                    location.reload();
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },

    UpdateTrangThai2: function (id) {
        var lydo = $('#LyDo2').val();
        $.ajax({
            url: '/WebMaster/UpdateTrangThaiShop',
            data: {
                id: id,
                lydo: lydo
            },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status) {
                    alert(response.mess);
                    location.reload();
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },

    HienLyDo: function (id) {
        $.ajax({
            url: '/WebMaster/HienLyDoShop',
            data: {
                id: id
            },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status) {
                    $('#LyDo2').val(response.lydo);
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },

    LayThongTinHoaDonVi: function (id) {
        $.ajax({
            url: '/WebMaster/LayThongTinVi',
            data: { id: id },
            type: 'POST',
            dataType: 'json',
            success: function (response) {
                if (response.status) {
                    if (response.trangThai === 0)
                    {
                        $('#hiID').val(response.maHD);
                        $('#TenShop').val(response.tenShop);
                        $('#TenTKNH').val(response.tenTKNH);
                        $('#SoTKNH').val(response.soTKNH);
                        $('#SoTienNap').val(response.soTienNap);
                        $('#NgayHoaDon').val(response.ngay);
                    }
                    else
                    {
                        $('#txthiID').val(response.maHD);
                        $('#txtTenShop').val(response.tenShop);
                        $('#txtTenTKNH').val(response.tenTKNH);
                        $('#txtSoTKNH').val(response.soTKNH);
                        $('#txtSoTienNap').val(response.soTienNap);
                        $('#txtNgayHoaDon').val(response.ngay);
                    }
                }
            },
            error: function (err) {
                console.log(err);
            }
        });
    },

    XacNhanHoaDon: function (id,value) {
        $.ajax({
            url: '/WebMaster/XacNhanHoaDonVi',
            data: {
                id: id,
                value: value
            },
            type: 'POST',
            dataType: 'json',
            success: function (data) {
                alert(data.mess);
                location.reload();
            },
            error: function (err) {
                console.log(err);
            }
        });
    }
};
user.init();