﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//using 2 thư viện để thiết kế metadata
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using static WebBanGiay.Models.Giay;

namespace WebBanGiay.Models
{
    [MetadataType(typeof(GiayMetadate))]
    public partial class  Giay
    {
        internal sealed class GiayMetadate
        {
            [Display(Name = "Mã giày")]//Thuộc tính Display
            public int MaGiay { get; set; }
            [Required(ErrorMessage = "{0} không được để trống")]
            [Display(Name = "Tên giày")]//Thuộc tính Display
            public string TenGiay { get; set; }
            [Required(ErrorMessage = "{0} không được để trống")]
            [Display(Name = "Giá bán")]//Thuộc tính Display
            public Nullable<decimal> GiaBan { get; set; }
            [Required(ErrorMessage = "{0} không được để trống")]
            [Display(Name = "Mô tả")]//Thuộc tính Display
            public string MoTa { get; set; }
            [Display(Name = "Ngày cập nhập")]//Thuộc tính Display
            [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]//Định dạng dữ liệu
            [DataType(DataType.Date)]//Dùng để hổ trợ kiểu dữ liệu ngày
            public Nullable<System.DateTime> NgayCapNhap { get; set; }
            [Required(ErrorMessage = "{0} không được để trống")]
            [Display(Name = "Hãng")]//Thuộc tính Display
            public Nullable<int> MaHang { get; set; }
            [Required(ErrorMessage = "{0} không được để trống")]
            [Display(Name = "Shop")]//Thuộc tính Display
            public Nullable<int> MaShop { get; set; }
            [Required(ErrorMessage = "{0} không được để trống")]
            [Display(Name = "Sale")]//Thuộc tính Display
            public Nullable<int> Sale { get; set; }
        }
    }
}