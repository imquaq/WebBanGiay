﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebBanGiay.Models
{
    public class GioHang
    {
        QuanLyBanGiayEntities db = new QuanLyBanGiayEntities();
        public int iMaGiay { get; set; }
        public string sTenGiay { get; set; }
        public string sAnhBia { get; set; }
        public double dDonGia { get; set; }

        public int? iMaShop { get; set; }
        public int iSoLuong { get; set; }
        public int iSize { get; set; }
        public double dThanhTien { get { return iSoLuong * dDonGia; } }
        public GioHang(int MaGiay,int iSize)
        {
            iMaGiay = MaGiay;
            Giay giay = db.Giays.SingleOrDefault(p => p.MaGiay == iMaGiay);
            iMaShop = giay.MaShop;
            sTenGiay = giay.TenGiay;
            sAnhBia = giay.TenGiay;
            dDonGia = double.Parse((giay.GiaBan-(giay.GiaBan*giay.Sale/100)).ToString());
            this.iSize = iSize;
            iSoLuong = 1;
        }
    }
}