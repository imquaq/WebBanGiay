﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebBanGiay.Models
{
    public class DKKhachHang
    {
        [Display(Name = "Họ và tên")]
        [Required(ErrorMessage = "{0} không được để trống")]

        public string HoTen { get; set; }
        [Display(Name = "Số điện thoại")]
        [Required(ErrorMessage = "{0} không được để trống")]


        public string DienThoai { get; set; }
        [Display(Name = "Email")]
        [Required(ErrorMessage = "{0} không được để trống")]
        [RegularExpression(@"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$",ErrorMessage = "{0} không hợp lệ")]


        public string Email { get; set; }
        [Display(Name = "Địa chỉ")]
        [Required(ErrorMessage = "{0} không được để trống")]

        public string DiaChi { get; set; }
        [Display(Name = "Tài khoản")]
        [Required(ErrorMessage = "{0} không được để trống")]

        public string TaiKhoan { get; set; }
        [Display(Name = "Mật khẩu")]
        [Required(ErrorMessage = "{0} không được để trống")]

        public string MatKhau { get; set; }
    }
}