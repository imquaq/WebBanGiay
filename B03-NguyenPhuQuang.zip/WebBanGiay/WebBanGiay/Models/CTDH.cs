﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebBanGiay.Models
{
    public class CTDH
    {
        public int MaGiay { get; set; }
        public string TenGiay { get; set; }
        public int? SL { get; set; }
        public int? Size { get; set; }
        public CTDH()
        {

        }
    }

}